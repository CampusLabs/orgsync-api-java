# Getting Started

To setup your project to use the OrgSync Java API client library, you must add it as a
dependency to your project.  This can be accomplished either by using a dependency
management system like [Maven][maven], [Gradle][gradle], etc, or by adding the jar
and its depencies directly to the classpath.

## Adding a dependency

TODO Maven POM info

## Download the jar

TODO links to download location

  [maven]: http://maven.apache.org/
  [gradle]: http://www.gradle.org/